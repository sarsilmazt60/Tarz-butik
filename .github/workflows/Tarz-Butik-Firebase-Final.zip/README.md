# Tarz Butik

Firebase web SDK ile çalışan ortak sipariş/kargo paneli. Android APK içinde yerel WebView üzerinden çalışır.

Firebase ayarları `app/src/main/assets/index.html` içindedir.
