package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentItem
import com.example.data.repository.OrderRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class DashboardMetrics(
    val totalRemainingBalance: Double = 0.0,
    val pendingCargoCount: Int = 0,
    val waitingPaymentCount: Int = 0,
    val preparingCount: Int = 0,
    val totalOrdersCount: Int = 0
)

class TarzButikViewModel(
    private val repository: OrderRepository = OrderRepository()
) : ViewModel() {

    val currentUser: StateFlow<FirebaseUser?> = repository.currentUser
    val isLoading: StateFlow<Boolean> = repository.isLoading
    val syncStatus: StateFlow<String> = repository.syncStatus

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow("Hepsi")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    val orders: StateFlow<List<Order>> = repository.orders

    // Filtered and searched orders
    val filteredOrders: StateFlow<List<Order>> = combine(
        repository.orders,
        _searchQuery,
        _selectedFilter
    ) { orderList, query, filter ->
        val trimmedQuery = query.trim().lowercase()
        orderList.filter { order ->
            val matchesFilter = when (filter) {
                "Hepsi" -> true
                "Bakiyesi Kalanlar" -> order.remainingAmount > 0.01 && order.status != OrderStatus.IPTAL
                else -> order.status == filter
            }

            val matchesSearch = if (trimmedQuery.isEmpty()) {
                true
            } else {
                order.customerName.lowercase().contains(trimmedQuery) ||
                order.phone.lowercase().contains(trimmedQuery) ||
                order.itemDescription.lowercase().contains(trimmedQuery) ||
                order.trackingNumber.lowercase().contains(trimmedQuery) ||
                order.address.lowercase().contains(trimmedQuery) ||
                order.note.lowercase().contains(trimmedQuery)
            }

            matchesFilter && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Calculated top metrics
    val dashboardMetrics: StateFlow<DashboardMetrics> = repository.orders.combine(
        MutableStateFlow(Unit)
    ) { orderList, _ ->
        val activeOrders = orderList.filter { it.status != OrderStatus.IPTAL }
        val remainingSum = activeOrders.sumOf { it.remainingAmount }
        val pendingCargo = orderList.count { it.status == OrderStatus.HAZIRLANIYOR || it.status == OrderStatus.KARGODA }
        val waitingPayment = orderList.count { it.status == OrderStatus.ODEME_BEKLENIYOR || (it.remainingAmount > 0.01 && it.status != OrderStatus.IPTAL) }
        val preparing = orderList.count { it.status == OrderStatus.HAZIRLANIYOR }
        val total = orderList.size

        DashboardMetrics(
            totalRemainingBalance = remainingSum,
            pendingCargoCount = pendingCargo,
            waitingPaymentCount = waitingPayment,
            preparingCount = preparing,
            totalOrdersCount = total
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardMetrics()
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onFilterSelected(filter: String) {
        _selectedFilter.value = filter
    }

    fun saveNewOrder(
        customerName: String,
        phone: String,
        address: String,
        itemDescription: String,
        size: String,
        color: String,
        totalAmount: Double,
        initialPaidAmount: Double,
        cargoCompany: String,
        trackingNumber: String,
        source: String,
        status: String,
        note: String,
        onSuccess: () -> Unit
    ) {
        val initialPayments = if (initialPaidAmount > 0) {
            listOf(
                PaymentItem(
                    id = UUID.randomUUID().toString(),
                    amount = initialPaidAmount,
                    date = System.currentTimeMillis(),
                    note = "İlk Peşinat / Alınan Ödeme"
                )
            )
        } else {
            emptyList()
        }

        val remaining = (totalAmount - initialPaidAmount).coerceAtLeast(0.0)

        val newOrder = Order(
            customerName = customerName.trim(),
            phone = phone.trim(),
            address = address.trim(),
            itemDescription = itemDescription.trim(),
            size = size.trim(),
            color = color.trim(),
            totalAmount = totalAmount,
            paidAmount = initialPaidAmount,
            remainingAmount = remaining,
            cargoCompany = cargoCompany,
            trackingNumber = trackingNumber.trim(),
            source = source,
            status = status,
            note = note.trim(),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            payments = initialPayments
        )

        repository.saveOrder(newOrder) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Sipariş başarıyla kaydedildi!")
                    onSuccess()
                } else {
                    _userMessage.emit("Kayıt hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun addPayment(orderId: String, amount: Double, note: String, onDone: () -> Unit) {
        if (amount <= 0) {
            viewModelScope.launch { _userMessage.emit("Geçerli bir ödeme tutarı girin") }
            return
        }
        repository.addPaymentToOrder(orderId, amount, note) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("₺$amount tutarında ödeme eklendi.")
                    onDone()
                } else {
                    _userMessage.emit("Ödeme ekleme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        repository.updateOrderStatus(orderId, newStatus) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Sipariş durumu '$newStatus' olarak güncellendi.")
                } else {
                    _userMessage.emit("Durum güncelleme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun updateCargoInfo(orderId: String, cargoCompany: String, trackingNumber: String, onDone: () -> Unit) {
        repository.updateCargoInfo(orderId, cargoCompany, trackingNumber) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Kargo bilgisi güncellendi.")
                    onDone()
                } else {
                    _userMessage.emit("Kargo güncelleme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun deleteOrder(orderId: String, onDone: () -> Unit) {
        repository.deleteOrder(orderId) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Sipariş silindi.")
                    onDone()
                } else {
                    _userMessage.emit("Silme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun signIn(email: String, pass: String, onResult: (Result<FirebaseUser>) -> Unit) {
        repository.signIn(email, pass) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Giriş başarılı! Hoş geldiniz.")
                } else {
                    _userMessage.emit("Giriş hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
                onResult(result)
            }
        }
    }

    fun signUp(email: String, pass: String, onResult: (Result<FirebaseUser>) -> Unit) {
        repository.signUp(email, pass) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Hesap oluşturuldu ve giriş yapıldı.")
                } else {
                    _userMessage.emit("Kayıt hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
                onResult(result)
            }
        }
    }

    fun signOut() {
        repository.signOut()
        viewModelScope.launch {
            _userMessage.emit("Çıkış yapıldı.")
        }
    }
}
