package com.example.data.repository

import android.util.Log
import com.example.data.model.Order
import com.example.data.model.PaymentItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class OrderRepository {
    private val TAG = "OrderRepository"

    private val auth: FirebaseAuth?
        get() = try {
            FirebaseAuth.getInstance()
        } catch (e: Throwable) {
            Log.w(TAG, "FirebaseAuth not initialized: ${e.message}")
            null
        }

    private val firestore: FirebaseFirestore?
        get() = try {
            FirebaseFirestore.getInstance()
        } catch (e: Throwable) {
            Log.w(TAG, "FirebaseFirestore not initialized: ${e.message}")
            null
        }

    private var snapshotListener: ListenerRegistration? = null

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _syncStatus = MutableStateFlow("Hazır")
    val syncStatus: StateFlow<String> = _syncStatus.asStateFlow()

    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    init {
        try {
            val currentAuth = auth
            if (currentAuth != null) {
                _currentUser.value = currentAuth.currentUser
                currentAuth.addAuthStateListener { firebaseAuth ->
                    _currentUser.value = firebaseAuth.currentUser
                    if (firebaseAuth.currentUser != null) {
                        startRealtimeOrderListener()
                    } else {
                        stopRealtimeOrderListener()
                    }
                }
                if (currentAuth.currentUser != null) {
                    startRealtimeOrderListener()
                } else {
                    // Try listening even without auth if rules permit or start listener
                    startRealtimeOrderListener()
                }
            } else {
                _syncStatus.value = "Çevrimdışı Mod"
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Init Firebase error: ${e.message}")
            _syncStatus.value = "Çevrimdışı Mod"
        }
    }

    fun startRealtimeOrderListener() {
        val fs = firestore ?: run {
            _syncStatus.value = "Çevrimdışı"
            return
        }

        snapshotListener?.remove()
        _isLoading.value = true
        _syncStatus.value = "Senkronize Ediliyor..."

        try {
            snapshotListener = fs.collection("orders")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshots, e ->
                    _isLoading.value = false
                    if (e != null) {
                        Log.e(TAG, "Listen failed: ${e.message}", e)
                        _syncStatus.value = "Çevrimdışı"
                        return@addSnapshotListener
                    }

                    if (snapshots != null) {
                        val orderList = snapshots.documents.mapNotNull { doc ->
                            try {
                                val data = doc.data
                                if (data != null) {
                                    Order.fromMap(doc.id, data)
                                } else null
                            } catch (parseEx: Exception) {
                                Log.e(TAG, "Error parsing doc ${doc.id}", parseEx)
                                null
                            }
                        }
                        _orders.value = orderList
                        _syncStatus.value = "Canlı Senkronize"
                    }
                }
        } catch (ex: Exception) {
            Log.e(TAG, "Error starting snapshot listener", ex)
            _isLoading.value = false
            _syncStatus.value = "Bağlantı Hatası"
        }
    }

    fun stopRealtimeOrderListener() {
        snapshotListener?.remove()
        snapshotListener = null
        _syncStatus.value = "Giriş Yapılmadı"
    }

    fun saveOrder(order: Order, onComplete: (Result<String>) -> Unit) {
        val fs = firestore
        val orderId = if (order.id.isNotBlank()) order.id else UUID.randomUUID().toString()
        val orderWithId = order.copy(
            id = orderId,
            updatedAt = System.currentTimeMillis()
        )

        // Always update local list immediately for instant responsive UI
        val currentList = _orders.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.id == orderId }
        if (existingIndex >= 0) {
            currentList[existingIndex] = orderWithId
        } else {
            currentList.add(0, orderWithId)
        }
        _orders.value = currentList

        if (fs != null) {
            fs.collection("orders").document(orderId)
                .set(orderWithId.toMap())
                .addOnSuccessListener {
                    onComplete(Result.success(orderId))
                }
                .addOnFailureListener { ex ->
                    Log.e(TAG, "Failed to save order to Firestore: ${ex.message}", ex)
                    // Still successful locally
                    onComplete(Result.success(orderId))
                }
        } else {
            onComplete(Result.success(orderId))
        }
    }

    fun addPaymentToOrder(orderId: String, amount: Double, note: String, onComplete: (Result<Unit>) -> Unit) {
        val currentOrder = _orders.value.find { it.id == orderId }
        if (currentOrder == null) {
            onComplete(Result.failure(Exception("Sipariş bulunamadı")))
            return
        }

        val newPayment = PaymentItem(
            id = UUID.randomUUID().toString(),
            amount = amount,
            date = System.currentTimeMillis(),
            note = note.ifBlank { "Ödeme" }
        )

        val updatedPayments = currentOrder.payments + newPayment
        val newPaidAmount = updatedPayments.sumOf { it.amount }
        val newRemainingAmount = (currentOrder.totalAmount - newPaidAmount).coerceAtLeast(0.0)

        val updatedOrder = currentOrder.copy(
            payments = updatedPayments,
            paidAmount = newPaidAmount,
            remainingAmount = newRemainingAmount,
            updatedAt = System.currentTimeMillis()
        )

        // Update local list immediately
        val currentList = _orders.value.toMutableList()
        val idx = currentList.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            currentList[idx] = updatedOrder
            _orders.value = currentList
        }

        val fs = firestore
        if (fs != null) {
            val updates = mapOf(
                "payments" to updatedPayments.map { it.toMap() },
                "paidAmount" to newPaidAmount,
                "remainingAmount" to newRemainingAmount,
                "updatedAt" to System.currentTimeMillis()
            )

            fs.collection("orders").document(orderId)
                .update(updates)
                .addOnSuccessListener {
                    onComplete(Result.success(Unit))
                }
                .addOnFailureListener { ex ->
                    Log.e(TAG, "Failed to add payment to Firestore", ex)
                    onComplete(Result.success(Unit))
                }
        } else {
            onComplete(Result.success(Unit))
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String, onComplete: (Result<Unit>) -> Unit) {
        val currentList = _orders.value.toMutableList()
        val idx = currentList.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            currentList[idx] = currentList[idx].copy(status = newStatus, updatedAt = System.currentTimeMillis())
            _orders.value = currentList
        }

        val fs = firestore
        if (fs != null) {
            fs.collection("orders").document(orderId)
                .update(
                    mapOf(
                        "status" to newStatus,
                        "updatedAt" to System.currentTimeMillis()
                    )
                )
                .addOnSuccessListener { onComplete(Result.success(Unit)) }
                .addOnFailureListener { onComplete(Result.success(Unit)) }
        } else {
            onComplete(Result.success(Unit))
        }
    }

    fun updateCargoInfo(orderId: String, cargoCompany: String, trackingNumber: String, onComplete: (Result<Unit>) -> Unit) {
        val currentList = _orders.value.toMutableList()
        val idx = currentList.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            currentList[idx] = currentList[idx].copy(
                cargoCompany = cargoCompany,
                trackingNumber = trackingNumber,
                updatedAt = System.currentTimeMillis()
            )
            _orders.value = currentList
        }

        val fs = firestore
        if (fs != null) {
            fs.collection("orders").document(orderId)
                .update(
                    mapOf(
                        "cargoCompany" to cargoCompany,
                        "trackingNumber" to trackingNumber,
                        "updatedAt" to System.currentTimeMillis()
                    )
                )
                .addOnSuccessListener { onComplete(Result.success(Unit)) }
                .addOnFailureListener { onComplete(Result.success(Unit)) }
        } else {
            onComplete(Result.success(Unit))
        }
    }

    fun deleteOrder(orderId: String, onComplete: (Result<Unit>) -> Unit) {
        val currentList = _orders.value.toMutableList()
        currentList.removeAll { it.id == orderId }
        _orders.value = currentList

        val fs = firestore
        if (fs != null) {
            fs.collection("orders").document(orderId)
                .delete()
                .addOnSuccessListener { onComplete(Result.success(Unit)) }
                .addOnFailureListener { onComplete(Result.success(Unit)) }
        } else {
            onComplete(Result.success(Unit))
        }
    }

    fun signIn(email: String, pass: String, onComplete: (Result<FirebaseUser>) -> Unit) {
        val a = auth
        if (a == null) {
            onComplete(Result.failure(Exception("Firebase Auth başlatılamadı")))
            return
        }
        a.signInWithEmailAndPassword(email.trim(), pass)
            .addOnSuccessListener { result ->
                _currentUser.value = result.user
                startRealtimeOrderListener()
                result.user?.let { onComplete(Result.success(it)) }
            }
            .addOnFailureListener { ex ->
                onComplete(Result.failure(ex))
            }
    }

    fun signUp(email: String, pass: String, onComplete: (Result<FirebaseUser>) -> Unit) {
        val a = auth
        if (a == null) {
            onComplete(Result.failure(Exception("Firebase Auth başlatılamadı")))
            return
        }
        a.createUserWithEmailAndPassword(email.trim(), pass)
            .addOnSuccessListener { result ->
                _currentUser.value = result.user
                startRealtimeOrderListener()
                result.user?.let { onComplete(Result.success(it)) }
            }
            .addOnFailureListener { ex ->
                onComplete(Result.failure(ex))
            }
    }

    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "Sign out error", e)
        }
        _currentUser.value = null
        stopRealtimeOrderListener()
    }
}
