package com.example.data.model

object OrderStatus {
    const val HAZIRLANIYOR = "Hazırlanıyor"
    const val ODEME_BEKLENIYOR = "Ödeme Bekleniyor"
    const val KARGODA = "Kargoda"
    const val TESLIM_EDILDI = "Teslim Edildi"
    const val IPTAL = "İptal"

    val allStatuses = listOf(
        HAZIRLANIYOR,
        ODEME_BEKLENIYOR,
        KARGODA,
        TESLIM_EDILDI,
        IPTAL
    )
}

object CargoCompanies {
    val list = listOf(
        "Yurtiçi",
        "Aras",
        "MNG",
        "PTT",
        "Sürat",
        "Trendyol Express",
        "Diğer"
    )
}

object OrderSources {
    val list = listOf(
        "WhatsApp",
        "Canlı Yayın",
        "Instagram",
        "Diğer"
    )
}

object CommonSizes {
    val list = listOf(
        "Standart",
        "XS",
        "S",
        "M",
        "L",
        "XL",
        "XXL",
        "36",
        "38",
        "40",
        "42",
        "44"
    )
}
