package com.example

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class TarzButikApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        initializeFirebase()
    }

    private fun initializeFirebase() {
        try {
            if (FirebaseApp.getApps(this).isNotEmpty()) return

            val options = FirebaseOptions.Builder()
                .setApiKey("AIzaSyDSdfh155-N2oscJv0uBqgNXJkRQAC8gaA")
                .setApplicationId("1:264475881310:web:b3869e3b2586ac1f1329cf")
                .setProjectId("tarz-butik")
                .setStorageBucket("tarz-butik.firebasestorage.app")
                .build()

            FirebaseApp.initializeApp(this, options)
            Log.i("TarzButikFirebase", "Firebase başarıyla başlatıldı")
        } catch (e: Exception) {
            Log.e("TarzButikFirebase", "Firebase başlatılamadı", e)
        }
    }
}
