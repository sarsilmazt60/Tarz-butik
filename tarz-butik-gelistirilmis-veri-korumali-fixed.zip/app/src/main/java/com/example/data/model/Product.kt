package com.example.data.model

data class Product(
    val id: String = "",
    val name: String = "",
    val sku: String = "",
    val stock: Int = 0,
    val purchasePrice: Double = 0.0,
    val salePrice: Double = 0.0,
    val minStock: Int = 5,
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toMap() = mapOf(
        "id" to id, "name" to name, "sku" to sku, "stock" to stock,
        "purchasePrice" to purchasePrice, "salePrice" to salePrice,
        "minStock" to minStock, "updatedAt" to updatedAt
    )
    companion object {
        fun fromMap(id: String, m: Map<String, Any?>) = Product(
            id = id,
            name = m["name"] as? String ?: "",
            sku = m["sku"] as? String ?: "",
            stock = (m["stock"] as? Number)?.toInt() ?: 0,
            purchasePrice = (m["purchasePrice"] as? Number)?.toDouble() ?: 0.0,
            salePrice = (m["salePrice"] as? Number)?.toDouble() ?: 0.0,
            minStock = (m["minStock"] as? Number)?.toInt() ?: 5,
            updatedAt = (m["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }
}
