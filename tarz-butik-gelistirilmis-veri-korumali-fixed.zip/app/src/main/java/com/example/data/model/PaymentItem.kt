package com.example.data.model

data class PaymentItem(
    val id: String = "",
    val amount: Double = 0.0,
    val date: Long = System.currentTimeMillis(),
    val note: String = ""
) {
    fun toMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "amount" to amount,
            "date" to date,
            "note" to note
        )
    }

    companion object {
        fun fromMap(map: Map<String, Any?>): PaymentItem {
            return PaymentItem(
                id = map["id"] as? String ?: "",
                amount = (map["amount"] as? Number)?.toDouble() ?: 0.0,
                date = (map["date"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                note = map["note"] as? String ?: ""
            )
        }
    }
}
