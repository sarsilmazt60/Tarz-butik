package com.example.data.model

data class Order(
    val id: String = "",
    val customerName: String = "",
    val phone: String = "",
    val address: String = "",
    val itemDescription: String = "",
    val size: String = "",
    val color: String = "",
    val totalAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val remainingAmount: Double = 0.0,
    val cargoCompany: String = "Yurtiçi",
    val trackingNumber: String = "",
    val source: String = "WhatsApp",
    val status: String = OrderStatus.HAZIRLANIYOR,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val payments: List<PaymentItem> = emptyList(),
    val productId: String = "",
    val productQuantity: Int = 0,
    val unitSalePrice: Double = 0.0,
    val unitCost: Double = 0.0
) {
    val isFullyPaid: Boolean
        get() = totalAmount > 0 && remainingAmount <= 0.001

    fun toMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "customerName" to customerName,
            "phone" to phone,
            "address" to address,
            "itemDescription" to itemDescription,
            "size" to size,
            "color" to color,
            "totalAmount" to totalAmount,
            "paidAmount" to paidAmount,
            "remainingAmount" to remainingAmount,
            "cargoCompany" to cargoCompany,
            "trackingNumber" to trackingNumber,
            "source" to source,
            "status" to status,
            "note" to note,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt,
            "payments" to payments.map { it.toMap() },
            "productId" to productId,
            "productQuantity" to productQuantity,
            "unitSalePrice" to unitSalePrice,
            "unitCost" to unitCost
        )
    }

    companion object {
        @Suppress("UNCHECKED_CAST")
        fun fromMap(id: String, map: Map<String, Any?>): Order {
            val total = (map["totalAmount"] as? Number)?.toDouble() ?: 0.0
            val paid = (map["paidAmount"] as? Number)?.toDouble() ?: 0.0
            val remaining = (map["remainingAmount"] as? Number)?.toDouble() ?: (total - paid).coerceAtLeast(0.0)

            val rawPayments = map["payments"] as? List<Map<String, Any?>> ?: emptyList()
            val parsedPayments = rawPayments.map { PaymentItem.fromMap(it) }

            return Order(
                id = id,
                customerName = map["customerName"] as? String ?: "",
                phone = map["phone"] as? String ?: "",
                address = map["address"] as? String ?: "",
                itemDescription = map["itemDescription"] as? String ?: "",
                size = map["size"] as? String ?: "",
                color = map["color"] as? String ?: "",
                totalAmount = total,
                paidAmount = paid,
                remainingAmount = remaining,
                cargoCompany = map["cargoCompany"] as? String ?: "Yurtiçi",
                trackingNumber = map["trackingNumber"] as? String ?: "",
                source = map["source"] as? String ?: "WhatsApp",
                status = map["status"] as? String ?: OrderStatus.HAZIRLANIYOR,
                note = map["note"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                payments = parsedPayments,
                productId = map["productId"] as? String ?: "",
                productQuantity = (map["productQuantity"] as? Number)?.toInt() ?: 0,
                unitSalePrice = (map["unitSalePrice"] as? Number)?.toDouble() ?: 0.0,
                unitCost = (map["unitCost"] as? Number)?.toDouble() ?: 0.0
            )
        }
    }
}
