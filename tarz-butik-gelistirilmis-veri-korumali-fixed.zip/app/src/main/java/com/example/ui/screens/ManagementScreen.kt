package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.ui.viewmodel.TarzButikViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagementScreen(viewModel: TarzButikViewModel, onBack: () -> Unit) {
    val products by viewModel.products.collectAsState()
    val orders by viewModel.orders.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var min by remember { mutableStateOf("5") }
    var bagPhone by remember { mutableStateOf("") }
    var bagCount by remember { mutableStateOf(0) }
    var showBag by remember { mutableStateOf(false) }
    val bagMap = remember { mutableStateMapOf<String, Int>() }
    val fmt = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("tr-TR"))

    val customers = orders.filter { it.phone.isNotBlank() }.groupBy { it.phone.filter(Char::isDigit) }
        .map { (_, list) -> list.maxByOrNull { it.createdAt }!! to list }
        .sortedBy { it.first.customerName.lowercase() }

    LaunchedEffect(customers.map { it.first.phone }) {
        customers.forEach { (latest, _) -> viewModel.loadCustomerBag(latest.phone) { bagMap[latest.phone.filter(Char::isDigit)] = it } }
    }

    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("Stok • Cari • Raporlar", fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { pad ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("📊 Ciro ve Kâr", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            val active = orders.filter { it.status != "İptal" }
            val totalRevenue = active.sumOf { it.totalAmount }
            val knownProfit = active.sumOf { if (it.productQuantity > 0) it.totalAmount - it.unitCost * it.productQuantity else 0.0 }
            item { Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("Toplam Ciro: ${fmt.format(totalRevenue)}", fontWeight = FontWeight.Bold); Text("Kayıtlı maliyeti olan siparişlerden brüt kâr: ${fmt.format(knownProfit)}"); Text("Eski siparişlerde alış maliyeti yoksa kâr hesabına dahil edilmez.", style = MaterialTheme.typography.bodySmall) } } }

            item { Text("🏷️ Stoklar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            item { Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Yeni Ürün Ekle") } }
            if (products.isEmpty()) item { Card { Text("Henüz ürün eklenmemiş. Etek, gömlek vb. ürünleri buradan tanımlayabilirsin.", Modifier.padding(16.dp)) } }
            items(products) { p -> Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(p.name, fontWeight = FontWeight.Bold); Text("Stok: ${p.stock}", fontWeight = FontWeight.Bold) }; Text("Alış: ${fmt.format(p.purchasePrice)} • Satış: ${fmt.format(p.salePrice)}"); if (p.stock <= p.minStock) Text("⚠️ Kritik stok", color = MaterialTheme.colorScheme.error) } } }

            item { Text("👥 Müşteriler / Cari", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            item { Text("${customers.size} benzersiz telefon kaydı • Aynı müşteriye yeni sipariş mevcut kayda bağlanır.", style = MaterialTheme.typography.bodyMedium) }
            items(customers.take(100)) { (latest, list) ->
                val total = list.sumOf { it.totalAmount }; val paid = list.sumOf { it.paidAmount }; val key = latest.phone.filter(Char::isDigit); val bags = bagMap[key] ?: 0
                Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(latest.customerName.ifBlank { "İsimsiz" }, fontWeight = FontWeight.Bold); Text("${latest.phone} • ${list.size} sipariş"); Text("Ciro: ${fmt.format(total)} • Kalan: ${fmt.format((total-paid).coerceAtLeast(0.0))}"); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("🛍️ Poşet: $bags", fontWeight = FontWeight.Bold); TextButton(onClick={ bagPhone=latest.phone; bagCount=bags; showBag=true }) { Text("Düzenle") } } } }
            }
        }
    }
    if (showBag) AlertDialog(onDismissRequest={showBag=false}, title={Text("Müşteri Poşet Bakiyesi")}, text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { Text(bagPhone); OutlinedTextField(value=bagCount.toString(), onValueChange={bagCount=it.toIntOrNull()?.coerceAtLeast(0)?:0}, label={Text("Poşet adedi")}) } }, confirmButton={TextButton(onClick={viewModel.setCustomerBag(bagPhone,bagCount){bagMap[bagPhone.filter(Char::isDigit)]=bagCount;showBag=false}}){Text("Kaydet")}}, dismissButton={TextButton(onClick={showBag=false}){Text("İptal")}})
    if (showAdd) AlertDialog(onDismissRequest = { showAdd=false }, title={Text("Yeni Ürün")}, text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name,{name=it},label={Text("Ürün adı")}); OutlinedTextField(sku,{sku=it},label={Text("Stok kodu (opsiyonel)")}); OutlinedTextField(stock,{stock=it},label={Text("Stok adedi")}); OutlinedTextField(buy,{buy=it},label={Text("Alış fiyatı")}); OutlinedTextField(sell,{sell=it},label={Text("Satış fiyatı")}); OutlinedTextField(min,{min=it},label={Text("Kritik stok")})
    }}, confirmButton={ TextButton(onClick={ viewModel.saveProduct(name,sku,stock.toIntOrNull()?:0,buy.toDoubleOrNull()?:0.0,sell.toDoubleOrNull()?:0.0,min.toIntOrNull()?:5){showAdd=false}; name=""; sku=""; stock=""; buy=""; sell=""; min="5" }){Text("Kaydet")} }, dismissButton={TextButton(onClick={showAdd=false}){Text("İptal")}})
}
