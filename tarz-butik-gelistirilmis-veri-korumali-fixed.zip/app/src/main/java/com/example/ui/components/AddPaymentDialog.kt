package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.ui.theme.BoutiqueBerryPrimary
import com.example.ui.theme.ColorTamOdendi
import java.text.NumberFormat
import java.util.Locale

@Composable
fun AddPaymentDialog(
    order: Order,
    onDismiss: () -> Unit,
    onConfirm: (amount: Double, note: String) -> Unit
) {
    var amountText by remember { mutableStateOf(if (order.remainingAmount > 0) order.remainingAmount.toString().removeSuffix(".0") else "") }
    var noteText by remember { mutableStateOf("Havale / EFT") }
    val paymentMethods = listOf("Havale / EFT", "Kredi Kartı", "Kapıda Ödeme", "Nakit", "IBAN / FAST")

    val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
    val newRemaining = (order.remainingAmount - parsedAmount).coerceAtLeast(0.0)

    val turkishLocale = Locale.forLanguageTag("tr-TR")
    val currencyFormat = NumberFormat.getCurrencyInstance(turkishLocale).apply {
        maximumFractionDigits = 2
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BoutiqueBerryPrimary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Payment,
                        contentDescription = null,
                        tint = BoutiqueBerryPrimary
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Parçalı Ödeme Ekle",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = order.customerName,
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Info Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Toplam Sipariş:", style = MaterialTheme.typography.bodySmall)
                            Text(currencyFormat.format(order.totalAmount), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Şu Ana Kadar Ödenen:", style = MaterialTheme.typography.bodySmall)
                            Text(currencyFormat.format(order.paidAmount), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = ColorTamOdendi))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Mevcut Kalan Bakiye:", style = MaterialTheme.typography.bodySmall)
                            Text(currencyFormat.format(order.remainingAmount), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = BoutiqueBerryPrimary))
                        }
                    }
                }

                // Payment input
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Eklenecek Ödeme Tutarı (₺)") },
                    placeholder = { Text("Örn: 300") },
                    leadingIcon = {
                        Text("₺", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Quick Method buttons
                Text(
                    text = "Ödeme Yöntemi / Açıklama",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    paymentMethods.take(3).forEach { method ->
                        val isSelected = noteText == method
                        OutlinedButton(
                            onClick = { noteText = method },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = if (isSelected) {
                                ButtonDefaults.outlinedButtonColors(
                                    containerColor = BoutiqueBerryPrimary.copy(alpha = 0.15f),
                                    contentColor = BoutiqueBerryPrimary
                                )
                            } else {
                                ButtonDefaults.outlinedButtonColors()
                            }
                        ) {
                            Text(method, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                }

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Ödeme Açıklaması") },
                    leadingIcon = {
                        Icon(Icons.Default.EditNote, contentDescription = null)
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Remaining Preview
                if (parsedAmount > 0) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (newRemaining <= 0.001) ColorTamOdendi.copy(alpha = 0.15f) else BoutiqueBerryPrimary.copy(alpha = 0.1f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (newRemaining <= 0.001) "Bu ödeme ile TAM ÖDENDİ olacak" else "İşlem sonrası kalan bakiye:",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                        )
                        Text(
                            text = currencyFormat.format(newRemaining),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (newRemaining <= 0.001) ColorTamOdendi else BoutiqueBerryPrimary
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (parsedAmount > 0) {
                        onConfirm(parsedAmount, noteText)
                    }
                },
                enabled = parsedAmount > 0,
                colors = ButtonDefaults.buttonColors(containerColor = BoutiqueBerryPrimary)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Ödemeyi Kaydet")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Vazgeç")
            }
        }
    )
}
