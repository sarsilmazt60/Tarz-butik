package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = BoutiqueBerryPrimary,
    onPrimary = Color.White,
    primaryContainer = BoutiqueBerryPrimaryContainer,
    onPrimaryContainer = BoutiqueOnPrimaryContainer,
    secondary = BoutiqueSecondary,
    onSecondary = Color.White,
    secondaryContainer = BoutiqueSecondaryContainer,
    onSecondaryContainer = Color(0xFF2B151C),
    tertiary = BoutiqueTertiary,
    onTertiary = Color.White,
    tertiaryContainer = BoutiqueTertiaryContainer,
    onTertiaryContainer = Color(0xFF2E1500),
    background = BoutiqueBackground,
    onBackground = Color(0xFF201A1B),
    surface = BoutiqueSurface,
    onSurface = Color(0xFF201A1B),
    surfaceVariant = BoutiqueSurfaceVariant,
    onSurfaceVariant = Color(0xFF514347),
    outline = BoutiqueOutline
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFFB0C8),
    onPrimary = Color(0xFF541031),
    primaryContainer = Color(0xFF701E42),
    onPrimaryContainer = Color(0xFFFFD9E2),
    secondary = Color(0xFFE3BDC7),
    onSecondary = Color(0xFF422931),
    secondaryContainer = Color(0xFF5A3F47),
    onSecondaryContainer = Color(0xFFFED9E3),
    background = Color(0xFF191114),
    onBackground = Color(0xFFECE0E2),
    surface = Color(0xFF21191C),
    onSurface = Color(0xFFECE0E2),
    surfaceVariant = Color(0xFF514347),
    onSurfaceVariant = Color(0xFFD5C2C6)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep boutique brand colors consistent
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
