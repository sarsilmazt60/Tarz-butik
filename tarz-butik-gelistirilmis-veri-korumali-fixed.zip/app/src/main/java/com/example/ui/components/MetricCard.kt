package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BoutiqueBerryPrimary
import com.example.ui.theme.BoutiqueOnPrimaryContainer
import com.example.ui.theme.ColorBakiyeKalan
import com.example.ui.theme.ColorHazirlaniyor
import com.example.ui.theme.ColorKargoda
import com.example.ui.theme.ColorOdemeBekleniyor
import com.example.ui.viewmodel.DashboardMetrics
import java.text.NumberFormat
import java.util.Locale

@Composable
fun DashboardOverview(
    metrics: DashboardMetrics,
    onFilterSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val turkishLocale = Locale.forLanguageTag("tr-TR")
    val currencyFormat = NumberFormat.getCurrencyInstance(turkishLocale).apply {
        maximumFractionDigits = 0
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Hero Card: Toplam Kalan Bakiye
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onFilterSelect("Bakiyesi Kalanlar") },
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            listOf(
                                BoutiqueBerryPrimary,
                                Color(0xFF591B35)
                            )
                        )
                    )
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TOPLAM KALAN BAKİYE",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currencyFormat.format(metrics.totalRemainingBalance),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "Müşterilerden tahsil edilecek toplam tutar",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.75f)
                            )
                        )
                    }
                }
            }
        }

        // Ciro / Kâr özetleri
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricSubCard(title = "Bugün Ciro", value = currencyFormat.format(metrics.todayRevenue), icon = Icons.Default.Payments, iconBg = BoutiqueBerryPrimary.copy(alpha = 0.12f), iconTint = BoutiqueBerryPrimary, modifier = Modifier.weight(1f), onClick = { onFilterSelect("Hepsi") })
            MetricSubCard(title = "Bugün Kâr", value = currencyFormat.format(metrics.todayProfit), icon = Icons.Default.CheckCircle, iconBg = ColorHazirlaniyor.copy(alpha = 0.12f), iconTint = ColorHazirlaniyor, modifier = Modifier.weight(1f), onClick = { onFilterSelect("Hepsi") })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricSubCard(title = "Bu Hafta Ciro", value = currencyFormat.format(metrics.weekRevenue), icon = Icons.Default.Payments, iconBg = ColorKargoda.copy(alpha = 0.12f), iconTint = ColorKargoda, modifier = Modifier.weight(1f), onClick = { onFilterSelect("Hepsi") })
            MetricSubCard(title = "Bu Hafta Kâr", value = currencyFormat.format(metrics.weekProfit), icon = Icons.Default.CheckCircle, iconBg = ColorOdemeBekleniyor.copy(alpha = 0.12f), iconTint = ColorOdemeBekleniyor, modifier = Modifier.weight(1f), onClick = { onFilterSelect("Hepsi") })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricSubCard(title = "Bu Ay Ciro", value = currencyFormat.format(metrics.monthRevenue), icon = Icons.Default.Payments, iconBg = BoutiqueBerryPrimary.copy(alpha = 0.12f), iconTint = BoutiqueBerryPrimary, modifier = Modifier.weight(1f), onClick = { onFilterSelect("Hepsi") })
            MetricSubCard(title = "Bu Ay Kâr", value = currencyFormat.format(metrics.monthProfit), icon = Icons.Default.CheckCircle, iconBg = ColorHazirlaniyor.copy(alpha = 0.12f), iconTint = ColorHazirlaniyor, modifier = Modifier.weight(1f), onClick = { onFilterSelect("Hepsi") })
        }

        // 4 Sub-metrics grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricSubCard(
                title = "Bekleyen Kargo",
                value = "${metrics.pendingCargoCount}",
                icon = Icons.Default.LocalShipping,
                iconBg = ColorKargoda.copy(alpha = 0.15f),
                iconTint = ColorKargoda,
                modifier = Modifier.weight(1f),
                onClick = { onFilterSelect("Kargoda") }
            )
            MetricSubCard(
                title = "Ödeme Bekleyen",
                value = "${metrics.waitingPaymentCount}",
                icon = Icons.Default.Payments,
                iconBg = ColorOdemeBekleniyor.copy(alpha = 0.15f),
                iconTint = ColorOdemeBekleniyor,
                modifier = Modifier.weight(1f),
                onClick = { onFilterSelect("Ödeme Bekleniyor") }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricSubCard(
                title = "Hazırlanıyor",
                value = "${metrics.preparingCount}",
                icon = Icons.Default.PendingActions,
                iconBg = ColorHazirlaniyor.copy(alpha = 0.15f),
                iconTint = ColorHazirlaniyor,
                modifier = Modifier.weight(1f),
                onClick = { onFilterSelect("Hazırlanıyor") }
            )
            MetricSubCard(
                title = "Toplam Sipariş",
                value = "${metrics.totalOrdersCount}",
                icon = Icons.Default.Assignment,
                iconBg = BoutiqueBerryPrimary.copy(alpha = 0.15f),
                iconTint = BoutiqueBerryPrimary,
                modifier = Modifier.weight(1f),
                onClick = { onFilterSelect("Hepsi") }
            )
        }
    }
}

@Composable
fun MetricSubCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    ),
                    maxLines = 1
                )
            }
        }
    }
}
