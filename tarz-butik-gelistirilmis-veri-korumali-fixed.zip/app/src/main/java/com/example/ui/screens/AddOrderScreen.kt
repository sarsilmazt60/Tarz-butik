package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CargoCompanies
import com.example.data.model.CommonSizes
import com.example.data.model.OrderSources
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.ui.theme.BoutiqueBerryPrimary
import com.example.ui.theme.ColorBakiyeKalan
import com.example.ui.theme.ColorTamOdendi
import com.example.ui.viewmodel.TarzButikViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrderScreen(
    viewModel: TarzButikViewModel,
    onNavigateBack: () -> Unit,
    existingOrder: Order? = null,
    modifier: Modifier = Modifier
) {
    // Form fields
    var customerName by remember(existingOrder) { mutableStateOf(existingOrder?.customerName ?: "") }
    var phone by remember(existingOrder) { mutableStateOf(existingOrder?.phone ?: "") }
    var address by remember(existingOrder) { mutableStateOf(existingOrder?.address ?: "") }
    var itemDescription by remember(existingOrder) { mutableStateOf(existingOrder?.itemDescription ?: "") }
    var size by remember(existingOrder) { mutableStateOf(existingOrder?.size ?: "Standart") }
    var color by remember(existingOrder) { mutableStateOf(existingOrder?.color ?: "") }
    var totalAmountText by remember(existingOrder) { mutableStateOf(if (existingOrder != null) existingOrder.totalAmount.toString() else "") }
    var initialPaidText by remember(existingOrder) { mutableStateOf(if (existingOrder != null) existingOrder.paidAmount.toString() else "") }
    var cargoCompany by remember(existingOrder) { mutableStateOf(existingOrder?.cargoCompany ?: "Yurtiçi") }
    var trackingNumber by remember(existingOrder) { mutableStateOf(existingOrder?.trackingNumber ?: "") }
    var source by remember(existingOrder) { mutableStateOf(existingOrder?.source ?: "WhatsApp") }
    var status by remember(existingOrder) { mutableStateOf(existingOrder?.status ?: OrderStatus.HAZIRLANIYOR) }
    var note by remember(existingOrder) { mutableStateOf(existingOrder?.note ?: "") }
    val products by viewModel.products.collectAsState()
    var selectedProductId by remember(existingOrder) { mutableStateOf(existingOrder?.productId ?: "") }
    var productQtyText by remember(existingOrder) { mutableStateOf(if ((existingOrder?.productQuantity ?: 0) > 0) existingOrder!!.productQuantity.toString() else "") }
    var unitSalePrice by remember(existingOrder) { mutableStateOf(existingOrder?.unitSalePrice ?: 0.0) }
    var unitCost by remember(existingOrder) { mutableStateOf(existingOrder?.unitCost ?: 0.0) }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Live calculation of remaining amount
    val totalAmount = totalAmountText.toDoubleOrNull() ?: 0.0
    val initialPaid = initialPaidText.toDoubleOrNull() ?: 0.0
    val remainingAmount = (totalAmount - initialPaid).coerceAtLeast(0.0)

    val turkishLocale = Locale.forLanguageTag("tr-TR")
    val currencyFormat = NumberFormat.getCurrencyInstance(turkishLocale).apply {
        maximumFractionDigits = 2
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = if (existingOrder == null) "Yeni Sipariş Oluştur" else "Siparişi Düzenle",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Customer Information
            FormSectionHeader(title = "Müşteri Bilgileri", icon = Icons.Default.Person)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Müşteri Adı Soyadı *") },
                        placeholder = { Text("Örn: Ayşe Yılmaz") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Telefon Numarası *") },
                        placeholder = { Text("Örn: 0555 123 45 67") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Açık Adres (İlçe/İl Dahil)") },
                        placeholder = { Text("Örn: Atatürk Mah. Gül Sok. No:5 D:2 Kadıköy / İstanbul") },
                        leadingIcon = { Icon(Icons.Default.Home, contentDescription = null) },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Stoktan ürün seçimi
            FormSectionHeader(title = "Stoktan Ürün Seç", icon = Icons.Default.ShoppingBag)
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(
                            value = products.find { it.id == selectedProductId }?.name ?: "Manuel ürün / stok seçilmedi",
                            onValueChange = {}, readOnly = true, label = { Text("Ürün") }, modifier = Modifier.fillMaxWidth().menuAnchor(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
                        )
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            products.forEach { product ->
                                DropdownMenuItem(text = { Text("${product.name} • Stok ${product.stock} • ${product.salePrice} ₺") }, onClick = {
                                    selectedProductId = product.id; unitSalePrice = product.salePrice; unitCost = product.purchasePrice; itemDescription = product.name; expanded = false
                                    if (totalAmountText.isBlank()) totalAmountText = product.salePrice.toString()
                                })
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(value = productQtyText, onValueChange = { productQtyText = it.filter(Char::isDigit) }, label = { Text("Adet") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                        if (selectedProductId.isNotBlank()) Text("Mevcut stok: ${products.find { it.id == selectedProductId }?.stock ?: 0}", modifier = Modifier.weight(1f).padding(top = 16.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            // Section 2: Order & Product Details
            FormSectionHeader(title = "Sipariş & Ürün Detayı", icon = Icons.Default.ShoppingBag)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = itemDescription,
                        onValueChange = { itemDescription = it },
                        label = { Text("Sipariş İçeriği / Ürünler *") },
                        placeholder = { Text("Örn: Desenli Şifon Elbise, Keten Gömlek") },
                        leadingIcon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Size Selection Chips
                    Text(
                        text = "Beden",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CommonSizes.list.forEach { sizeOption ->
                            val isSelected = size == sizeOption
                            FilterChip(
                                selected = isSelected,
                                onClick = { size = sizeOption },
                                label = { Text(sizeOption, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BoutiqueBerryPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = size,
                            onValueChange = { size = it },
                            label = { Text("Özel Beden") },
                            placeholder = { Text("38, L vb.") },
                            leadingIcon = { Icon(Icons.Default.Straighten, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = color,
                            onValueChange = { color = it },
                            label = { Text("Renk") },
                            placeholder = { Text("Pudra, Siyah") },
                            leadingIcon = { Icon(Icons.Default.Palette, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Section 3: Payment & Balance
            FormSectionHeader(title = "Ödeme & Bakiye", icon = Icons.Default.Payments)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = totalAmountText,
                            onValueChange = { totalAmountText = it },
                            label = { Text("Toplam Tutar (₺) *") },
                            placeholder = { Text("Örn: 850") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = initialPaidText,
                            onValueChange = { initialPaidText = it },
                            label = { Text("Alınan Ödeme (₺)") },
                            placeholder = { Text("Örn: 500") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Automatic calculation badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (totalAmount > 0 && remainingAmount <= 0.001) ColorTamOdendi.copy(alpha = 0.12f) else BoutiqueBerryPrimary.copy(alpha = 0.1f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (totalAmount > 0 && remainingAmount <= 0.001) "Ödeme Durumu: TAM ÖDENDİ" else "Kalan Bakiye (Otomatik):",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                                )
                                Text(
                                    text = "Toplam: ${currencyFormat.format(totalAmount)} • Alınan: ${currencyFormat.format(initialPaid)}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            Text(
                                text = currencyFormat.format(remainingAmount),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (totalAmount > 0 && remainingAmount <= 0.001) ColorTamOdendi else ColorBakiyeKalan
                                )
                            )
                        }
                    }
                }
            }

            // Section 4: Cargo & Source & Status
            FormSectionHeader(title = "Kargo, Kaynak & Durum", icon = Icons.Default.LocalShipping)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Cargo Company Selector
                    Text(
                        text = "Kargo Firması",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CargoCompanies.list.forEach { company ->
                            val isSelected = cargoCompany == company
                            FilterChip(
                                selected = isSelected,
                                onClick = { cargoCompany = company },
                                label = { Text(company, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BoutiqueBerryPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = trackingNumber,
                        onValueChange = { trackingNumber = it },
                        label = { Text("Kargo Takip Numarası") },
                        placeholder = { Text("Örn: 123456789012") },
                        leadingIcon = { Icon(Icons.Default.LocalShipping, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Order Source
                    Text(
                        text = "Sipariş Kaynağı",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OrderSources.list.forEach { src ->
                            val isSelected = source == src
                            FilterChip(
                                selected = isSelected,
                                onClick = { source = src },
                                label = { Text(src, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BoutiqueBerryPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    // Order Status
                    Text(
                        text = "Sipariş Durumu",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OrderStatus.allStatuses.forEach { st ->
                            val isSelected = status == st
                            FilterChip(
                                selected = isSelected,
                                onClick = { status = st },
                                label = { Text(st, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BoutiqueBerryPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Sipariş Notu") },
                        placeholder = { Text("Örn: Acil hediye paketi yapılsın") },
                        leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null) },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Error message if any
            if (errorMessage != null) {
                Text(
                    text = errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            // Save Button
            Button(
                onClick = {
                    if (customerName.isBlank()) {
                        errorMessage = "Lütfen müşteri adını girin."
                        return@Button
                    }
                    if (phone.isBlank()) {
                        errorMessage = "Lütfen telefon numarasını girin."
                        return@Button
                    }
                    if (itemDescription.isBlank()) {
                        errorMessage = "Lütfen sipariş içeriğini girin."
                        return@Button
                    }
                    if (totalAmount <= 0) {
                        errorMessage = "Lütfen geçerli bir toplam sipariş tutarı girin."
                        return@Button
                    }

                    errorMessage = null
                    isSaving = true

                    if (existingOrder != null) {
                        viewModel.updateExistingOrder(existingOrder, customerName, phone, address, itemDescription, size, color, totalAmount, initialPaid, cargoCompany, trackingNumber, source, status, note, selectedProductId, productQtyText.toIntOrNull() ?: 0, unitSalePrice, unitCost) { isSaving = false; onNavigateBack() }
                    } else viewModel.saveNewOrder(
                        customerName = customerName,
                        phone = phone,
                        address = address,
                        itemDescription = itemDescription,
                        size = size,
                        color = color,
                        totalAmount = totalAmount,
                        initialPaidAmount = initialPaid,
                        cargoCompany = cargoCompany,
                        trackingNumber = trackingNumber,
                        source = source,
                        status = status,
                        note = note,
                        productId = selectedProductId,
                        productQuantity = productQtyText.toIntOrNull() ?: 0,
                        unitSalePrice = unitSalePrice,
                        unitCost = unitCost,
                        onSuccess = {
                            isSaving = false
                            onNavigateBack()
                        }
                    )
                },
                enabled = !isSaving,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BoutiqueBerryPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
                } else {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Siparişi Kaydet", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun FormSectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BoutiqueBerryPrimary,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        )
    }
}
