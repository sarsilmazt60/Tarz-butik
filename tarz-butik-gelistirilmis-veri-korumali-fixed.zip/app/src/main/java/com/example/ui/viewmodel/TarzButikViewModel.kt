package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentItem
import com.example.data.model.Product
import com.example.data.repository.OrderRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.Calendar

data class DashboardMetrics(
    val totalRemainingBalance: Double = 0.0,
    val pendingCargoCount: Int = 0,
    val waitingPaymentCount: Int = 0,
    val preparingCount: Int = 0,
    val totalOrdersCount: Int = 0,
    val todayRevenue: Double = 0.0,
    val weekRevenue: Double = 0.0,
    val monthRevenue: Double = 0.0,
    val todayProfit: Double = 0.0,
    val weekProfit: Double = 0.0,
    val monthProfit: Double = 0.0
)

class TarzButikViewModel(
    private val repository: OrderRepository = OrderRepository()
) : ViewModel() {

    val currentUser: StateFlow<FirebaseUser?> = repository.currentUser
    val isLoading: StateFlow<Boolean> = repository.isLoading
    val syncStatus: StateFlow<String> = repository.syncStatus

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow("Hepsi")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    val orders: StateFlow<List<Order>> = repository.orders
    val products: StateFlow<List<Product>> = repository.products

    // Filtered and searched orders
    val filteredOrders: StateFlow<List<Order>> = combine(
        repository.orders,
        _searchQuery,
        _selectedFilter
    ) { orderList, query, filter ->
        val trimmedQuery = query.trim().lowercase()
        orderList.filter { order ->
            val matchesFilter = when (filter) {
                "Hepsi" -> true
                "Bakiyesi Kalanlar" -> order.remainingAmount > 0.01 && order.status != OrderStatus.IPTAL
                else -> order.status == filter
            }

            val matchesSearch = if (trimmedQuery.isEmpty()) {
                true
            } else {
                order.customerName.lowercase().contains(trimmedQuery) ||
                order.phone.lowercase().contains(trimmedQuery) ||
                order.itemDescription.lowercase().contains(trimmedQuery) ||
                order.trackingNumber.lowercase().contains(trimmedQuery) ||
                order.address.lowercase().contains(trimmedQuery) ||
                order.note.lowercase().contains(trimmedQuery)
            }

            matchesFilter && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Calculated top metrics
    val dashboardMetrics: StateFlow<DashboardMetrics> = repository.orders.combine(
        MutableStateFlow(Unit)
    ) { orderList, _ ->
        val activeOrders = orderList.filter { it.status != OrderStatus.IPTAL }
        val remainingSum = activeOrders.sumOf { it.remainingAmount }
        val pendingCargo = orderList.count { it.status == OrderStatus.HAZIRLANIYOR || it.status == OrderStatus.KARGODA }
        val waitingPayment = orderList.count { it.status == OrderStatus.ODEME_BEKLENIYOR || (it.remainingAmount > 0.01 && it.status != OrderStatus.IPTAL) }
        val preparing = orderList.count { it.status == OrderStatus.HAZIRLANIYOR }
        val total = orderList.size
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val dayStart = cal.timeInMillis
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        val weekStart = cal.timeInMillis
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val monthStart = cal.timeInMillis
        fun revenue(start: Long) = activeOrders.filter { it.createdAt >= start }.sumOf { it.totalAmount }
        fun profit(start: Long) = activeOrders.filter { it.createdAt >= start }.sumOf {
            if (it.productQuantity > 0) it.totalAmount - (it.unitCost * it.productQuantity) else 0.0
        }

        DashboardMetrics(
            totalRemainingBalance = remainingSum, pendingCargoCount = pendingCargo, waitingPaymentCount = waitingPayment,
            preparingCount = preparing, totalOrdersCount = total,
            todayRevenue = revenue(dayStart), weekRevenue = revenue(weekStart), monthRevenue = revenue(monthStart),
            todayProfit = profit(dayStart), weekProfit = profit(weekStart), monthProfit = profit(monthStart)
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardMetrics()
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onFilterSelected(filter: String) {
        _selectedFilter.value = filter
    }

    fun saveNewOrder(
        customerName: String,
        phone: String,
        address: String,
        itemDescription: String,
        size: String,
        color: String,
        totalAmount: Double,
        initialPaidAmount: Double,
        cargoCompany: String,
        trackingNumber: String,
        source: String,
        status: String,
        note: String,
        productId: String = "",
        productQuantity: Int = 0,
        unitSalePrice: Double = 0.0,
        unitCost: Double = 0.0,
        onSuccess: () -> Unit
    ) {
        val normalizedPhone = phone.filter(Char::isDigit)
        val existingCustomer = repository.orders.value.firstOrNull { it.phone.filter(Char::isDigit) == normalizedPhone && normalizedPhone.isNotBlank() }
        if (existingCustomer != null) {
            // Existing phone is a customer, not a duplicate customer; allow a new order under the same customer.
        }

        if (productId.isNotBlank() && productQuantity <= 0) {
            viewModelScope.launch { _userMessage.emit("Stoktan seçilen ürün için adet girin") }
            return
        }
        val selectedProduct = repository.products.value.find { it.id == productId }
        if (selectedProduct != null && productQuantity > selectedProduct.stock) {
            viewModelScope.launch { _userMessage.emit("Yetersiz stok. Mevcut: ${selectedProduct.stock}") }
            return
        }

        val initialPayments = if (initialPaidAmount > 0) {
            listOf(
                PaymentItem(
                    id = UUID.randomUUID().toString(),
                    amount = initialPaidAmount,
                    date = System.currentTimeMillis(),
                    note = "İlk Peşinat / Alınan Ödeme"
                )
            )
        } else {
            emptyList()
        }

        val remaining = (totalAmount - initialPaidAmount).coerceAtLeast(0.0)

        val newOrder = Order(
            customerName = customerName.trim(),
            phone = phone.trim(),
            address = address.trim(),
            itemDescription = itemDescription.trim(),
            size = size.trim(),
            color = color.trim(),
            totalAmount = totalAmount,
            paidAmount = initialPaidAmount,
            remainingAmount = remaining,
            cargoCompany = cargoCompany,
            trackingNumber = trackingNumber.trim(),
            source = source,
            status = status,
            note = note.trim(),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            payments = initialPayments,
            productId = productId, productQuantity = productQuantity, unitSalePrice = unitSalePrice, unitCost = unitCost
        )

        repository.saveOrder(newOrder) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    if (productId.isNotBlank() && productQuantity > 0) {
                        repository.adjustProductStock(productId, -productQuantity) { }
                    }
                    _userMessage.emit("Sipariş başarıyla kaydedildi!")
                    onSuccess()
                } else {
                    _userMessage.emit("Kayıt hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun updateExistingOrder(
        existing: Order, customerName: String, phone: String, address: String, itemDescription: String, size: String, color: String,
        totalAmount: Double, initialPaidAmount: Double, cargoCompany: String, trackingNumber: String, source: String, status: String, note: String,
        productId: String = existing.productId, productQuantity: Int = existing.productQuantity, unitSalePrice: Double = existing.unitSalePrice, unitCost: Double = existing.unitCost,
        onSuccess: () -> Unit
    ) {
        val selectedProduct = repository.products.value.find { it.id == productId }
        val delta = if (productId == existing.productId) existing.productQuantity - productQuantity else -productQuantity
        if (selectedProduct != null && productId != existing.productId && productQuantity > selectedProduct.stock) {
            viewModelScope.launch { _userMessage.emit("Yetersiz stok. Mevcut: ${selectedProduct.stock}") }; return
        }
        if (selectedProduct != null && productId == existing.productId && productQuantity > existing.productQuantity + selectedProduct.stock) {
            viewModelScope.launch { _userMessage.emit("Yetersiz stok. Mevcut: ${selectedProduct.stock + existing.productQuantity}") }; return
        }
        val paid = existing.paidAmount.coerceAtMost(totalAmount)
        val updated = existing.copy(
            customerName=customerName.trim(), phone=phone.trim(), address=address.trim(), itemDescription=itemDescription.trim(),
            size=size.trim(), color=color.trim(), totalAmount=totalAmount, paidAmount=paid, remainingAmount=(totalAmount-paid).coerceAtLeast(0.0),
            cargoCompany=cargoCompany, trackingNumber=trackingNumber.trim(), source=source, status=status, note=note.trim(),
            productId=productId, productQuantity=productQuantity, unitSalePrice=unitSalePrice, unitCost=unitCost, updatedAt=System.currentTimeMillis()
        )
        repository.saveOrder(updated) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    if (existing.productId.isNotBlank()) repository.adjustProductStock(existing.productId, existing.productQuantity, { })
                    if (productId.isNotBlank()) repository.adjustProductStock(productId, -productQuantity, { })
                    _userMessage.emit("Sipariş güncellendi")
                    onSuccess()
                } else _userMessage.emit("Sipariş güncellenemedi: ${result.exceptionOrNull()?.localizedMessage}")
            }
        }
    }

    fun loadCustomerBag(phone: String, onLoaded: (Int) -> Unit) { repository.getCustomerBag(phone, onLoaded) }
    fun setCustomerBag(phone: String, count: Int, onDone: () -> Unit) { repository.saveCustomerBag(phone, count) { r -> viewModelScope.launch { if (r.isSuccess) { _userMessage.emit("Poşet bakiyesi güncellendi"); onDone() } else _userMessage.emit("Poşet kaydedilemedi") } } }

    fun saveProduct(name: String, sku: String, stock: Int, purchasePrice: Double, salePrice: Double, minStock: Int, onDone: () -> Unit) {
        if (name.isBlank()) { viewModelScope.launch { _userMessage.emit("Ürün adı gerekli") }; return }
        repository.saveProduct(Product(name=name.trim(), sku=sku.trim(), stock=stock.coerceAtLeast(0), purchasePrice=purchasePrice, salePrice=salePrice, minStock=minStock.coerceAtLeast(0))) { r ->
            viewModelScope.launch { if (r.isSuccess) { _userMessage.emit("Ürün kaydedildi"); onDone() } else _userMessage.emit("Ürün kaydedilemedi: ${r.exceptionOrNull()?.localizedMessage}") }
        }
    }

    fun updateProduct(product: Product, onDone: () -> Unit) {
        repository.saveProduct(product) { r -> viewModelScope.launch { if (r.isSuccess) { _userMessage.emit("Ürün güncellendi"); onDone() } else _userMessage.emit("Ürün güncellenemedi") } }
    }

    fun addPayment(orderId: String, amount: Double, note: String, onDone: () -> Unit) {
        if (amount <= 0) {
            viewModelScope.launch { _userMessage.emit("Geçerli bir ödeme tutarı girin") }
            return
        }
        repository.addPaymentToOrder(orderId, amount, note) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("₺$amount tutarında ödeme eklendi.")
                    onDone()
                } else {
                    _userMessage.emit("Ödeme ekleme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        repository.updateOrderStatus(orderId, newStatus) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Sipariş durumu '$newStatus' olarak güncellendi.")
                } else {
                    _userMessage.emit("Durum güncelleme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun updateCargoInfo(orderId: String, cargoCompany: String, trackingNumber: String, onDone: () -> Unit) {
        repository.updateCargoInfo(orderId, cargoCompany, trackingNumber) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Kargo bilgisi güncellendi.")
                    onDone()
                } else {
                    _userMessage.emit("Kargo güncelleme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun deleteOrder(orderId: String, onDone: () -> Unit) {
        repository.deleteOrder(orderId) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Sipariş silindi.")
                    onDone()
                } else {
                    _userMessage.emit("Silme hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun signIn(email: String, pass: String, onSuccess: () -> Unit) {
        repository.signIn(email, pass) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Giriş başarılı! Hoş geldiniz.")
                    onSuccess()
                } else {
                    _userMessage.emit("Giriş hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun signUp(email: String, pass: String, onSuccess: () -> Unit) {
        repository.signUp(email, pass) { result ->
            viewModelScope.launch {
                if (result.isSuccess) {
                    _userMessage.emit("Hesap oluşturuldu ve giriş yapıldı.")
                    onSuccess()
                } else {
                    _userMessage.emit("Kayıt hatası: ${result.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun signOut() {
        repository.signOut()
        viewModelScope.launch {
            _userMessage.emit("Çıkış yapıldı.")
        }
    }
}
