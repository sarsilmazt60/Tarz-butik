package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BoutiqueBerryPrimary = Color(0xFF8C2D54)
val BoutiqueBerryPrimaryContainer = Color(0xFFFFD9E2)
val BoutiqueOnPrimaryContainer = Color(0xFF3B071F)

val BoutiqueSecondary = Color(0xFF73565F)
val BoutiqueSecondaryContainer = Color(0xFFFED9E3)

val BoutiqueTertiary = Color(0xFF7E5637)
val BoutiqueTertiaryContainer = Color(0xFFFFDCBE)

val BoutiqueBackground = Color(0xFFFCF7F9)
val BoutiqueSurface = Color(0xFFFFFFFF)
val BoutiqueSurfaceVariant = Color(0xFFF2DDE2)
val BoutiqueOutline = Color(0xFF837377)

// Status colors
val ColorHazirlaniyor = Color(0xFF0288D1)
val ColorHazirlaniyorBg = Color(0xFFE1F5FE)

val ColorOdemeBekleniyor = Color(0xFFF57C00)
val ColorOdemeBekleniyorBg = Color(0xFFFFF3E0)

val ColorKargoda = Color(0xFF7B1FA2)
val ColorKargodaBg = Color(0xFFF3E5F5)

val ColorTeslimEdildi = Color(0xFF2E7D32)
val ColorTeslimEdildiBg = Color(0xFFE8F5E9)

val ColorIptal = Color(0xFFC62828)
val ColorIptalBg = Color(0xFFFFEBEE)

val ColorBakiyeKalan = Color(0xFFD32F2F)
val ColorTamOdendi = Color(0xFF2E7D32)
