# Tarz Butik APK oluşturma

Bu proje GitHub Actions ile telefonda kullanılabilir debug APK üretmek üzere hazırlanmıştır.

1. Bu klasörün tamamını GitHub deposuna yükleyin.
2. GitHub'da **Actions** sekmesine girin.
3. **Tarz Butik APK** iş akışını seçin.
4. **Run workflow** ile çalıştırın.
5. İşlem tamamlanınca oluşan `tarz-butik-debug-apk` artifact'ini açıp `app-debug.apk` dosyasını indirin.
6. Android telefonda APK'yı açıp kuruluma izin verin.

Not: Firebase/Gemini gibi çevrimiçi özellikler için ilgili servis yapılandırmalarının ayrıca eklenmesi gerekebilir. APK derlemesi bunun için şart değildir.
